package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import org.example.dao.DAO;
import org.example.modelo.*;
import org.example.util.JpaUtil;

import java.io.BufferedReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("=== HIBERNATE 7.1.2 - JPA PURO ===");

        EntityManager em = null;
        EntityTransaction tx = null;

        try {
            // 1. Obtener EntityManager
            em = JpaUtil.getEntityManager();
            System.out.println(" EntityManager obtenido - Hibernate 7.1.2");

            // 2. Verificar conexión
            boolean connected = em.isOpen();
            System.out.println(" EntityManager abierto: " + connected);

            // 3. Iniciar transacción
            tx = em.getTransaction();


            // MENU CRUD
            String continuar;
            do {
                System.out.printf("%50s","-- CRUD BIBLIOTECA -- \n");
                System.out.printf("%35s %25s", "Insertar Libro", "(C [-r])\n");
                System.out.printf("%35s %25s", "Buscar Libro", " (R)\n");
                System.out.printf("%35s %25s", "Actualizar Libro", "(U)\n");
                System.out.printf("%35s %25s", "Eliminar Libro", "(D)\n");
                System.out.printf("%35s %25s", "Mostrar autores (-r recursivo)", "(muestra [-r] Autor)\n");
                System.out.printf("%35s %25s", "Mostrar usuarios (-r recursivo)", "(muestra [-r] Usuario)\n");
                System.out.printf("%35s %25s", "Salir", "(S)\n");
                System.out.printf(">>> ");

                switch (continuar = sc.nextLine().toUpperCase()) {
                    case "C":
                        DAO.create(em, tx, false);
                        break;
                    case "C -R":
                        DAO.create(em, tx, true);
                        break;
                    case "R":
                        DAO.read(em);
                        break;
                    case "U":
                        DAO.update(em, tx);
                        break;
                    case "D":
                        DAO.delete(em, tx);
                        break;
                    case "MUESTRA AUTOR":
                        DAO.mostrarAutores(em, false);
                        break;
                    case "MUESTRA -R AUTOR":
                        DAO.mostrarAutores(em, true);
                        break;
                    case "MUESTRA USUARIO":
                        DAO.mostrarUsuarios(em, false);
                        break;
                    case "MUESTRA -R USUARIO":
                        DAO.mostrarUsuarios(em, true);
                        break;
                }
            } while (!continuar.equalsIgnoreCase("S"));

        } catch (Exception e) {
            System.err.println(" ERROR: " + e.getMessage());
            if (tx != null && tx.isActive()) {
                tx.rollback();
                System.out.println(" Transacción revertida");
            }
            e.printStackTrace();
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
                System.out.println(" EntityManager cerrado");
            }
            JpaUtil.close();
        }
    }
}