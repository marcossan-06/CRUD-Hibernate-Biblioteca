package org.example.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import org.example.modelo.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class DAO {

    private static final Scanner sc = new Scanner(System.in);

    public static void read(EntityManager em) {
        System.out.println("Introduce el id del libro a buscar: ");
        int idLibro = sc.nextInt();
        sc.skip("\n");
        Libro libro = em.find(Libro.class, idLibro);
        if (libro == null) {
            System.out.printf("No existe el libro con el id: %d\n", idLibro);
            return;
        }
        System.out.println(libro);
    }

    public static void create(EntityManager em, EntityTransaction tx, boolean recursivo) {
        tx.begin();
        System.out.println("Transacción iniciada");

        System.out.println(" -- INSERTANDO LIBRO -- ");
        String titulo;
        do {
            System.out.println("Introduce el título del libro: ");
            titulo = sc.nextLine();
        }while (titulo.isEmpty());

        String nombre;
        String email;
        Autor autor = null;
        if (recursivo) {
            System.out.println("Selecciona ID del autor del libro: ");
            System.out.println("Autor 0 - Nuevo autor");
            System.out.println("-".repeat(20));
            mostrarAutores(em, false);
            System.out.print(">>> ");
            int idAutor = sc.nextInt();
            sc.skip("\n");
            if (idAutor != 0) {
                autor = em.find(Autor.class, idAutor);
            } else {
                do {
                    System.out.println("Introduce el nombre del nuevo autor: ");
                    autor = new Autor(nombre = sc.nextLine());
                } while (nombre.isEmpty());
            }
        }

        Usuario usuario = null;
        if (recursivo) {
            System.out.println("Prestar libro a usuario (ID): ");
            System.out.println("Usuario 0 - Nuevo usuario");
            System.out.println("-".repeat(20));
            mostrarUsuarios(em, false);
            System.out.print(">>> ");
            int idUsuario = sc.nextInt();
            sc.skip("\n");
            if (idUsuario != 0) {
                usuario = em.find(Usuario.class, idUsuario);
            } else {
                do {
                    System.out.println("Introduce el nombre del nuevo usuario: ");
                    nombre = sc.nextLine();
                    System.out.println("Introduce el correo del nuevo usuario: ");
                    email = sc.nextLine();
                } while (nombre.isEmpty() || email.isEmpty());
                usuario = new Usuario(nombre, email);
                TarjetaUsuario tarjeta = new TarjetaUsuario(Date.valueOf(LocalDate.now().plusYears(2)), usuario);
                usuario.setTarjetaUsuario(tarjeta);

                // persisto tarjeta y con cascade all se persiste el usuario
                em.persist(tarjeta);
            }
        }

        System.out.println("Introduce la fecha de publicación del libro (YYYY-MM-DD): ");
        String fechaPublicacionStr = sc.nextLine();

        Date fechaPublicacion = null;
        if (fechaPublicacionStr != null && !fechaPublicacionStr.isEmpty()) {
            try {
                fechaPublicacion = Date.valueOf(fechaPublicacionStr);
            } catch (IllegalArgumentException e) {
                System.out.println(fechaPublicacionStr + " no es una fecha válida");
            }
        }

        Libro libro = new Libro(titulo, autor, usuario, fechaPublicacion);
        em.persist(libro);
        em.flush();

        System.out.println("Libro persistido con ID: " + libro.getIdLibro());
        contarLibros(em);

        tx.commit();
        System.out.println(" Transacción confirmada");
    }

    public static void update(EntityManager em, EntityTransaction tx) {
        tx.begin();
        System.out.println("Transacción iniciada");
        System.out.println("Introduce el ID del libro que desea modificar: ");
        Integer idLibro = sc.nextInt();
        sc.skip("\n");
        Libro libro = em.find(Libro.class, idLibro);
        if (libro == null) {
            System.out.printf("No existe el libro con el id: %d\n", idLibro);
            tx.rollback();
            System.out.println(" Transacción revertida");
            return;
        }

        String titulo;
        int idUsuario;
        int idUsuarioFavorito;
        Date fechaPublicacion;
        Autor autor;
        String nombre;
        Usuario usuario;
        String email;

        System.out.printf(" -- ACTUALIZANDO LIBRO %d -- \n", idLibro);
        System.out.println("Introduce el nuevo título del libro: ");
        if (!( titulo = sc.nextLine()).isEmpty()) {
            libro.setTitulo(titulo);
        }


        System.out.println("Selecciona el nuevo autor del libro: ");
        System.out.println("Autor 0 - Nuevo autor");
        System.out.println("-".repeat(20));
        mostrarAutores(em, false);
        System.out.print(">>> ");
        int idAutor = sc.nextInt();
        sc.skip("\n");
        if (idAutor != 0) {
            autor = em.find(Autor.class, idAutor);
        } else {
            do {
                System.out.println("Introduce el nombre del nuevo autor: ");
                autor = new Autor(nombre = sc.nextLine());
            } while (nombre.isEmpty());
        }
        libro.setElAutor(autor);

        System.out.println("Introduce el nuevo usuario (ID): ");
        System.out.println("Usuario 0 - Nuevo usuario");
        System.out.println("-".repeat(20));
        mostrarUsuarios(em, false);
        System.out.print(">>> ");
        idUsuario = sc.nextInt();
        sc.skip("\n");
        if (idUsuario != 0) {
            usuario = em.find(Usuario.class, idUsuario);
        } else {
            do {
                System.out.println("Introduce el nombre del nuevo usuario: ");
                nombre = sc.nextLine();
                System.out.println("Introduce el correo del nuevo usuario: ");
                email = sc.nextLine();
            } while (nombre.isEmpty() || email.isEmpty());
            usuario = new Usuario(nombre, email);
            TarjetaUsuario tarjeta = new TarjetaUsuario(Date.valueOf(LocalDate.now()), usuario);
            usuario.setTarjetaUsuario(tarjeta);

            // persisto tarjeta y con cascade all se persiste el usuario
            em.persist(tarjeta);
        }
        libro.setElUsuario(usuario);

        System.out.println("Introduce 'Y' si deseas añadirlo a favoritos de un usuario: ");
        String addFav = sc.nextLine();
        if (addFav.equalsIgnoreCase("Y")) {
            System.out.println("Introduce el ID del usuario: ");
            idUsuarioFavorito = sc.nextInt();
            sc.skip("\n");
            Usuario usuarioFav = em.find(Usuario.class, idUsuarioFavorito);
            if (usuarioFav == null) {
                System.out.println("No existe el usuario con id: " + idUsuarioFavorito);
                tx.rollback();
                return;
            }

            Usuario_Favorito favorito = new Usuario_Favorito(Date.valueOf(LocalDate.now()));
            favorito.setUsuario(usuario);
            favorito.setLibro(libro);
            em.persist(favorito);
        }
        System.out.println("Introduce la nueva fecha de publicación del libro: ");
        String fechaPublicacionStr = sc.nextLine();

        if (fechaPublicacionStr != null && !fechaPublicacionStr.isEmpty()) {
            fechaPublicacion = Date.valueOf(fechaPublicacionStr);
            libro.setFechaPublicacion(fechaPublicacion);
        }

        // Con merge (para entidades detached)
        em.merge(libro);

        tx.commit();
        System.out.println(" Transacción confirmada");
    }

    public static void delete(EntityManager em, EntityTransaction tx) {
        tx.begin();
        System.out.println("Transacción iniciada");
        System.out.println("Introduce el ID del libro que desea eliminar: ");
        int idLibro = sc.nextInt();
        sc.skip("\n");
        Libro libro = em.find(Libro.class, idLibro);
        if (libro == null) {
            System.out.printf("No existe el libro con el id: %d\n", idLibro);
            tx.rollback();
            System.out.println(" Transacción revertida");
            return;
        }
        em.remove(libro);
        contarLibros(em);

        tx.commit();
        System.out.println(" Transacción confirmada");
    }


    public static void mostrarAutores(EntityManager em, boolean recursivo) {
        TypedQuery<Autor> q = em.createQuery("FROM Autor a", Autor.class);
        List<Autor> autor = q.getResultList();
        for (Autor a : autor) {
            System.out.println(a.toString());
            if (recursivo) {
                Set<Libro> librosDelAutor = a.getLosLibros();
                System.out.println(" -- Libros escritos --");
                for (Libro libro : librosDelAutor) {
                    System.out.println(libro.toString());
                }
            }
            System.out.println("-".repeat(20));
        }
    }

    public static void mostrarUsuarios(EntityManager em, boolean recursivo) {
        TypedQuery<Usuario> q = em.createQuery("FROM Usuario u", Usuario.class);
        List<Usuario> usuario = q.getResultList();
        for (Usuario u : usuario) {
            System.out.println(u.toString());
            if (recursivo) {
                Set<Libro> librosDelUsuario = u.getLosLibros();
                System.out.println(" -- Libros prestados --");
                for (Libro libro : librosDelUsuario) {
                    System.out.println(libro.toString());
                }
            }
            System.out.println("-".repeat(20));
        }
    }

    public static void contarLibros(EntityManager em) {
        Long count = em.createQuery("SELECT COUNT(l) FROM Libro l", Long.class).getSingleResult();
        System.out.println(" Total de libros en BD: " + count);
    }
}
