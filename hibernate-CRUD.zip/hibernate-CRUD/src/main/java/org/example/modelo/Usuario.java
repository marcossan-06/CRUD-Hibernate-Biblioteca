package org.example.modelo;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name = "Usuario")
@NoArgsConstructor

public class Usuario implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idUsuario;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "email", nullable = false, unique = true, length = 150)
    private String email;

    // 1:1 (tarjeta)
    @OneToOne(mappedBy = "usuario")
    private TarjetaUsuario tarjetaUsuario;

    // M:N (libros favoritos)
    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private List<Usuario_Favorito> favoritos = new ArrayList<>();

    // 1:M (libros que tiene)
    @OneToMany(mappedBy = "elUsuario",
            cascade = CascadeType.PERSIST,
            fetch = FetchType.LAZY)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Set<Libro> losLibros;



    // Constructor con parámetros
    public Usuario(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Usuario " + idUsuario + " - " + nombre + " (" + email + ") -- Tarjeta: " + tarjetaUsuario;
    }
}
