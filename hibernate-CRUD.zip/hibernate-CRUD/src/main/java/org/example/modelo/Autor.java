package org.example.modelo;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;
import java.util.Set;


@Data
@Entity
@Table(name = "Autor")
@NoArgsConstructor
public class Autor implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idAutor;

    @Column(name = "nombre", nullable = false, length = 150)
    private String nombre;

    // 1:M (libros escritos)
    @OneToMany(mappedBy = "elAutor",
            cascade = CascadeType.PERSIST,
            fetch = FetchType.LAZY)
    @ToString.Exclude
    private Set<Libro> losLibros;

    public Autor(String nombre) {
        this.nombre = nombre;
    }


    @Override
    public String toString() {
        return "Autor " + idAutor + " - " + nombre;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Autor autor = (Autor) o;
        return Objects.equals(idAutor, autor.idAutor) && Objects.equals(nombre, autor.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAutor, nombre);
    }
}