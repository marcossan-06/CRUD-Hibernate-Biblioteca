package org.example.modelo;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "Libro")
@NoArgsConstructor

public class Libro implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idLibro;

    @Column(name = "titulo", nullable = false, length = 200)
    private String titulo;

    @Column(name = "fechaPublicacion")
    private Date fechaPublicacion;

    // M:1 (autor)
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(
        name = "idAutor",
        foreignKey = @ForeignKey(name = "FK_LIB_AUT"))
    private Autor elAutor;

    // M:1 (usuario que lo tiene)
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(
            name = "idUsuario",
            foreignKey = @ForeignKey(name = "FK_LIB_USU"))
    private Usuario elUsuario;

    // M:N (favoritos)
    @OneToMany(mappedBy = "libro", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Usuario_Favorito> favoritos = new ArrayList<>();

    // Constructor con parámetros
    public Libro(String titulo, Autor elAutor , Usuario elUsuario, Date fechaPublicacion) {
        this.titulo = titulo;
        this.elAutor = elAutor;
        this.elUsuario = elUsuario;
        this.fechaPublicacion = fechaPublicacion;
    }

    @Override
    public String toString() {
        return "Libro{" +
                "idLibro=" + idLibro +
                ", titulo='" + titulo + '\'' +
                ", elUsuario=" + elUsuario +
                ", fechaPublicacion=" + fechaPublicacion +
                ", elAutor=" + elAutor +
                '}';
    }
}
