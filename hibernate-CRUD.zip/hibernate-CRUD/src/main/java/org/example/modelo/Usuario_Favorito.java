package org.example.modelo;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Date;

@Data
@Entity
@Table(name = "Usuario_Favorito")
@NoArgsConstructor
@AllArgsConstructor
public class Usuario_Favorito {

    @EmbeddedId
    private Usuario_FavoritoId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("idUsuario")
    @JoinColumn(name = "idUsuario")
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("idLibro")
    @JoinColumn(name = "idLibro")
    private Libro libro;

    @Column(name = "fechaMarcado", nullable = false, unique = true, length = 150)
    private Date fechaMarcado;

    public Usuario_Favorito(Date fechaMarcado) {
        this.id = new Usuario_FavoritoId();
        this.fechaMarcado = fechaMarcado;
    }

}