package org.example.modelo;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Date;

@Data
@Entity
@Table(name = "TarjetaUsuario")
@NoArgsConstructor
public class TarjetaUsuario implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idTarjeta;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(
            name = "idUsuario",
            referencedColumnName = "idUsuario",
            unique = true,
            nullable = false,
            foreignKey = @ForeignKey(name = "FK_TRJ_USER"))
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private Usuario usuario;

    @Column(name = "fechaExp")
    private Date fechaExp;


    // Constructor con parámetros
    public TarjetaUsuario(Date fechaExp, Usuario usuario) {
        this.fechaExp = fechaExp;
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return idTarjeta + " / " + fechaExp;
    }
}
