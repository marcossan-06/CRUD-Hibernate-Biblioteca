package org.example.modelo;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Date;


@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario_FavoritoId implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Column(name = "idUsuario", nullable = false)
    private Integer idUsuario;

    @Column(name = "idLibro", nullable = false)
    private Integer idLibro;
}