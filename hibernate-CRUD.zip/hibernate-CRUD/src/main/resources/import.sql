
DROP DATABASE IF EXISTS Biblioteca;
CREATE DATABASE Biblioteca;
USE Biblioteca;

-- ---- TABLA Usuario ----
CREATE TABLE Usuario (
                         idUsuario INT AUTO_INCREMENT PRIMARY KEY,
                         nombre VARCHAR(100) NOT NULL,
                         email VARCHAR(150) UNIQUE NOT NULL
);

-- ---- TABLA TarjetaUsuario (1:1 con Usuario) ----
CREATE TABLE TarjetaUsuario (
                                idTarjeta INT AUTO_INCREMENT PRIMARY KEY,
                                idUsuario INT UNIQUE NOT NULL,
                                fechaExp DATE,
                                FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario)
);

-- ---- TABLA Autor (1:M con Libro) ----
CREATE TABLE Autor (
                       idAutor INT AUTO_INCREMENT PRIMARY KEY,
                       nombre VARCHAR(150) NOT NULL
);

-- ---- TABLA Libro (Cada libro tiene UN autor y puede estar prestado a UN usuario) ----
CREATE TABLE Libro (
                       idLibro INT AUTO_INCREMENT PRIMARY KEY,
                       titulo VARCHAR(200) NOT NULL,
                       idAutor INT,        -- FK al autor (un libro tiene un único autor)
                       idUsuario INT DEFAULT NULL,  -- FK al usuario que lo tiene en préstamo (nullable)
                       fechaPublicacion DATETIME,
                       FOREIGN KEY (idAutor) REFERENCES Autor(idAutor),
                       FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario)
);

-- ---- TABLA Usuario_Favorito (N:M entre Usuario y Libro) ----
CREATE TABLE Usuario_Favorito (
                                  idUsuario INT NOT NULL,
                                  idLibro INT NOT NULL,
                                  fechaMarcado DATETIME DEFAULT CURRENT_TIMESTAMP,
                                  PRIMARY KEY (idUsuario, idLibro),
                                  FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario),
                                  FOREIGN KEY (idLibro) REFERENCES Libro(idLibro)
);

-- ---- Inserciones de ejemplo ----
-- Usuarios
INSERT INTO Usuario (nombre, email) VALUES
                                        ('Ana López', 'ana@example.com'),
                                        ('Carlos Pérez', 'carlos@example.com'),
                                        ('María Gómez', 'maria@example.com'),
                                        ('Sergio Ruiz', 'sergio@example.com');

-- Tarjetas (1:1)
INSERT INTO TarjetaUsuario (idUsuario, fechaExp) VALUES
                                                     (1, '2028-01-01'),
                                                     (2, '2027-06-15'),
                                                     (3, '2025-12-20'),
                                                     (4, '2026-03-10');

-- Autores
INSERT INTO Autor (nombre) VALUES
                               ('J.K. Rowling'),
                               ('George R.R. Martin'),
                               ('Brandon Sanderson'),
                               ('J. R. R. Tolkien'),
                               ('Rebecca Yarros');

-- Libros (cada libro tiene UN autor; idUsuario nullable)
INSERT INTO Libro (titulo, idAutor, idUsuario, fechaPublicacion) VALUES
                                                                     ('Harry Potter y la Piedra Filosofal', 1, 1, '1997-01-01'),
                                                                     ('Harry Potter y la Cámara Secreta', 1, NULL, '1998-11-21'),
                                                                     ('Juego de Tronos', 2, 2, '1996-01-01'),
                                                                     ('Choque de Reyes', 2, NULL, '1998-01-01'),
                                                                     ('El Imperio Final', 3, 3, '2006-01-01'),
                                                                     ('El Camino de los Reyes', 3, NULL, '2010-01-01'),
                                                                     ('El Señor de los Anillos: La Comunidad del Anillo', 4, NULL, '1954-01-01');

-- Favoritos (N:M) — usuarios marcando libros como favoritos
INSERT INTO Usuario_Favorito (idUsuario, idLibro) VALUES
                                                      (1, 1),
                                                      (1, 2),
                                                      (2, 3),
                                                      (3, 5),
                                                      (4, 7),
                                                      (2, 7),
                                                      (3, 1);